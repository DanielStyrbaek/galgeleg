package com.example.galgeleg.observers;

import androidx.fragment.app.Fragment;

public interface IObserver  {
    void update();
}
